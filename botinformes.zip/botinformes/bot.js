import { Telegraf, Markup, session } from 'telegraf';
import { dirname } from 'path';
import fs from 'fs-extra';
import path from 'path';
import { fileURLToPath } from 'url';
import { infoid } from './assets/bot/start.js';
import { upmain } from './assets/owner/up.js';
import { setlist, setfoto, setiepdfmain, setiecelmain, setrsmain, setenamain, setdatacelmain } from './assets/owner/set.js';
import { logCommandExecution } from './assets/bot/log.js';
import { exportLogs } from './assets/owner/export.js';
import { idarpdf } from './assets/com/idarg.js';
import { TELEGRAM_BOT_TOKEN, owner } from './assets/config/config.js';
import { cbusearchmain } from './assets/com/cbu.js';
import { datacelboton } from './assets/com/cel.js';
import { enacomboton } from './assets/com/enacom.js';
import { celmain } from './assets/com/celmain.js';
import { dnimain } from './assets/com/dni.js';
import { vehmain } from './assets/com/vehmain.js';
import { buscarpersonars } from './assets/com/buscarrs.js';
import { pdfrs } from './assets/com/pdfrs.js';
import { iepdf } from './assets/com/iepdf.js';
import { buscarpersonans } from './assets/com/buscarnosis.js';
import { addlogrs, listlogrs, dellogrs } from './assets/apilog/rs.js';
import { addlogie, listlogie, dellogie } from './assets/apilog/ie.js';
import { iecelboton } from './assets/com/iecel.js';
import { ieveh } from './assets/com/ieveh.js';
import { dnrpa } from './assets/com/dnrpa.js';
import { fotomainfoto } from './assets/com/foto.js';
import { verifyMembership } from './assets/bot/mid.js';
import {checkAndDeductSaldo} from './assets/bot/paid.js'
import { listUsers } from './assets/owner/listuser.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const bot = new Telegraf(TELEGRAM_BOT_TOKEN);
bot.use(session());
bot.use(verifyMembership);
bot.start(infoid);

bot.command('cbu', async (ctx) => {
    const userId = ctx.from.id;
    if (await checkAndDeductSaldo(ctx, userId)) {
        cbusearchmain(ctx);
    }
});

bot.command('cel', async (ctx) => {celmain(ctx);});
bot.command('dni', async (ctx) => {dnimain(ctx);});

bot.command('veh', async (ctx) => {
    const userId = ctx.from.id;
    if (await checkAndDeductSaldo(ctx, userId)) {
        vehmain(ctx);
    }
});

bot.command('buscar', async (ctx) => {
    const userId = ctx.from.id;
    if (await checkAndDeductSaldo(ctx, userId)) {
        buscarpersonars(ctx);
    }
});

bot.action(/^ENACOM (\d+) (\d+)$/, async (ctx) => {
    const userId = ctx.from.id;
    if (await checkAndDeductSaldo(ctx, userId)) {
        enacomboton(ctx);
    }
});

bot.action(/^DATACEL (\d+) (\d+)$/, async (ctx) => {
    const userId = ctx.from.id;
    if (await checkAndDeductSaldo(ctx, userId)) {
        datacelboton(ctx);
    }
});

bot.action(/^IECEL (\d+) (\d+)$/, async (ctx) => {
    const userId = ctx.from.id;
    if (await checkAndDeductSaldo(ctx, userId)) {
        iecelboton(ctx);
    }
});

bot.action(/^IEPDF (\d+) (\d+)$/, async (ctx) => {
    const userId = ctx.from.id;
    if (await checkAndDeductSaldo(ctx, userId)) {
        iepdf(ctx);
    }
});

bot.action(/^IEVEH (\d+) (\d+)$/, async (ctx) => {
    const userId = ctx.from.id;
    if (await checkAndDeductSaldo(ctx, userId)) {
        ieveh(ctx);
    }
});

bot.action(/^DNRPA (\d+) (\d+)$/, async (ctx) => {
    const userId = ctx.from.id;
    if (await checkAndDeductSaldo(ctx, userId)) {
        dnrpa(ctx);
    }
});

bot.action(/^RSPDF (\d+) (\d+)$/, async (ctx) => {
    const userId = ctx.from.id;
    if (await checkAndDeductSaldo(ctx, userId)) {
        const match = ctx.match;
        const inputNumber = match[1];
        const userId = match[2];
        pdfrs(ctx, inputNumber, userId);
    }
});

bot.action(/^fotofoto (\d+) ([MF]) (\d+)$/, async (ctx) => {
    const userId = ctx.from.id;
    if (await checkAndDeductSaldo(ctx, userId)) {
        const match = ctx.match;
        const inputNumber = match[1];
        const sex = match[2];
        const userId = match[3];
        fotomainfoto(bot, ctx, inputNumber, sex, userId);
    }
});

bot.action(/^idarg (\d+) ([MF]) (\d+)$/, async (ctx) => {
    const userId = ctx.from.id;
    if (await checkAndDeductSaldo(ctx, userId)) {
        const match = ctx.match;
        const inputNumber = match[1];
        const sex = match[2];
        const userId = match[3];
        idarpdf(bot, ctx, inputNumber, sex, userId);
    }
});

// ### OWNER ###
bot.command('up', upmain);

// SET API
bot.command('set', setlist);
bot.command('setfoto', setfoto);
bot.command('setiepdf', setiepdfmain);
bot.command('setiecel', setiecelmain);
bot.command('setrs', setrsmain);
bot.command('setena', setenamain);
bot.command('setdata', setdatacelmain);

bot.command('addrs', addlogrs);
bot.command('listrs', listlogrs);
bot.command('delrs', dellogrs);

bot.command('addie', addlogrs);
bot.command('listie', listlogie);
bot.command('delie', dellogie);

// EXPORT
bot.command('export', exportLogs);

// LIST USERS
bot.command('listuser', async (ctx) => {
    if (ctx.from.username === owner) {
        await listUsers(ctx);
    } 
});

bot.launch();
