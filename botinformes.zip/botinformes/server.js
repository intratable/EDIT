import express from 'express';
import { dirname } from 'path';
import { fileURLToPath } from 'url';
import { TELEGRAM_BOT_TOKEN, port, ipvps } from './assets/config/config.js';
import { cbusearch } from './server/cbu.js';
import { celsearch } from './server/cel.js';
import { enacomsearch } from './server/enacom.js';
import { pdfiemain } from './server/iepdf.js';
import { pdfrsmain } from './server/pdfrs.js';
import fetch from 'node-fetch';
import { fotomain } from './server/foto.js';
import { buscarrs } from './server/rs.js';
import {pdfidarg} from './server/idarg.js';
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const ip = ipvps;
app.use(express.json());

app.post('/cbu', cbusearch);
app.post('/datacel', celsearch);
app.post('/enacom', enacomsearch);
app.post('/buscarrs', buscarrs);
app.post('/pdfrs', pdfrsmain);
app.post('/foto', fotomain);
app.post('/idarg417', pdfidarg);

app.listen(port, () => {
    console.log(`Ready para el joseo http://localhost:${port}`);
});
