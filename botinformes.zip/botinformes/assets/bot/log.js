import { dirname } from 'path';
import { fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs-extra';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

//await logCommandExecution(ctx, 'paidcmd');

export const logCommandExecution = async (ctx, command) => {
    const logDir = path.join(__dirname, '../../');
    const logFile = path.join(logDir, 'command_logs.json');

    try {
        await fs.ensureDir(logDir);

        let logs = [];
        if (await fs.pathExists(logFile)) {
            logs = await fs.readJson(logFile);
        }

        const logEntry = {
            id: ctx.from.id,
            command,
            message: ctx.message.text,
            timestamp: new Date().toISOString()
        };

        logs.push(logEntry);
        await fs.writeJson(logFile, logs);
    } catch (error) {
        console.log('Error logging command execution:', error);
    }
};
