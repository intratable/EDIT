import { dirname } from 'path';
import { fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs-extra';


const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// const saldo = await getSaldo(userId);

export const getSaldo = async (userId) => {
    const dir = path.join(__dirname, '../../data', String(userId));
    const file = path.join(dir, `${userId}.json`);

    try {
        if (await fs.pathExists(file)) {
            const userData = await fs.readJson(file);
            return userData.saldo || 0;
        } else {
            return 0; 
        }
    } catch (error) {
        return 0; 
    }
};