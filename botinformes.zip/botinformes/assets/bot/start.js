import { dirname } from 'path';
import { fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs-extra';
import { Markup } from 'telegraf';
import { owner } from '../config/config.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const DISPLAY_NAMES = {
    userId: '🥷',
    MEMB: '',
 
};

export const infoid = async (ctx) => {

    const userId = ctx.from.id;
    const userMainDir = path.join(__dirname, '../../data', String(userId), 'main');
    const userAt = ctx.from.username;
    const dir = path.join(__dirname, '../../data', String(userId));
    const file = path.join(dir, `${userId}.json`);

    if (!fs.existsSync(file)) {
        const currentDate = new Date().toISOString();
        const data = {
            userId,
            userAt,
            MEMB: 0, 
            SALDO: 0,
            addedDate: currentDate
        };

        fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(file, JSON.stringify(data));
    }
  
    setTimeout(async () => {
        try {
            await ctx.telegram.deleteMessage(ctx.chat.id, ctx.message.message_id);
        } catch (error) {
            console.error('Error deleting messages:', error);
        }
    }, 1000);

    try {
        if (fs.existsSync(file)) {
            const fileContents = fs.readFileSync(file, 'utf8');
            const userData = JSON.parse(fileContents);
            
            let formattedData = '';
            
            for (const key in userData) {
                let displayName = DISPLAY_NAMES[key];
                let valueToShow = userData[key];
               
                if (key === "MEMB") {
                    if (valueToShow == 1) {
                        displayName = "𝙈𝙚𝙢𝙗𝙧𝙚𝙨𝙞𝙖";
                        valueToShow = " 𝗔𝗖𝗧𝗜𝗩𝗔";
                    } else if (valueToShow == 0) {
                        displayName = "𝙈𝙚𝙢𝙗𝙧𝙚𝙨𝙞𝙖";
                        valueToShow = " 𝗦𝗜𝗡 𝗔𝗖𝗧𝗜𝗩𝗔𝗥";
                    }
                }

                if (displayName) {
                    formattedData += `${displayName} <code>${valueToShow}</code>\n\n`;
                }
            }
            
            let inlineKeyboard = {};
            if (userData.MEMB != 1) {
                inlineKeyboard = {
                    inline_keyboard: [
                        [
                            {
                                text: "🛍️",
                                url: "https://t.me/" + owner
                            }
                        ]
                    ]
                };
            } else {
                inlineKeyboard = {
                    inline_keyboard: []
                };
            }
            
            if (userData.MEMB == 1) {
               
                const linkText = '𝐆𝐔𝐈𝐀 𝐃𝐄𝐓𝐀𝐋𝐋𝐀𝐃𝐀 𝐃𝐄 𝐔𝐒𝐎 ';
                const linkURL = 'https://t.me/+DOdSoWWQInZiNDIx';
                const styledText = `<a href="${linkURL}">${linkText}</a>`;
            
                ctx.replyWithHTML(`${styledText}`);
            }

            ctx.reply(formattedData, {
                parse_mode: 'HTML',
                reply_markup: inlineKeyboard
            });
        } 
    } catch (error) {
        console.log('Error reading user data:', error);
    }

}
