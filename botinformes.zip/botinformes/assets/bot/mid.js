import { dirname } from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import path from 'path';
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

export const verifyMembership = async (ctx, next) => {
    const userId = ctx.from.id;
    const filePath = path.join(__dirname, '../../data', String(userId), `${userId}.json`);

    if (ctx.message && ctx.message.text && ctx.message.text.startsWith('/start')) {
        return next(); // Allow the /start command for everyone
    }

    if (ctx.chat.type !== 'private') {
        return next(); // If the chat is not private, allow the message
    }

    if (!fs.existsSync(filePath)) {
        if (ctx.message) {
            try {
                await ctx.deleteMessage(ctx.message.message_id);
            } catch (error) {
                console.log('Failed to delete message:', error);
            }
        }
        return; // If the file doesn't exist, ignore and delete the message
    }

    const fileContents = fs.readFileSync(filePath, 'utf8');
    const userData = JSON.parse(fileContents);

    if (userData.MEMB === 1) {
        return next(); // User has an active membership, process the message
    } else {
        if (ctx.message) {
            try {
                await ctx.deleteMessage(ctx.message.message_id);
            } catch (error) {
                console.log('Failed to delete message:', error);
            }
        }
        // Optionally, you can send a message to the user explaining why their message was deleted
        // ctx.reply('Your membership is not active. Please activate your membership to use this bot.');
        return; // User does not have an active membership, ignore and delete the message
    }
};
