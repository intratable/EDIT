import { dirname } from 'path';
import { fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs-extra';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

export const checkAndDeductSaldo = async (ctx) => {
    const userId = ctx.from.id;
    const dir = path.join(__dirname, '../../data', String(userId));
    const file = path.join(dir, `${userId}.json`);

    try {
        if (await fs.pathExists(file)) {
            const userData = await fs.readJson(file);
            if (userData.SALDO > 0) {
                userData.SALDO -= 1;
                await fs.writeJson(file, userData);
                console.log(`Command executed. Your new SALDO is ${userData.SALDO}.`);
                return true;
            } else {
                console.log('You do not have enough SALDO to execute this command.');
                return false;
            }
        }
    } catch (error) {
        console.log('Error executing paid command:', error);
        return false;
    }
};