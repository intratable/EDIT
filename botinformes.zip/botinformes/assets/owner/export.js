import { dirname } from 'path';
import { fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs-extra';
import {owner} from '../config/config.js'

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);


export const exportLogs = async (ctx) => {
        if (ctx.from.username === owner) {
        const logDir = path.join(__dirname, '../../');
        const logFile = path.join(logDir, 'command_logs.json');

        try {
            if (await fs.pathExists(logFile)) {
                await ctx.replyWithDocument({
                    source: logFile
                });
            } else {
                ctx.reply('❌', { reply_to_message_id: ctx.message.message_id }) .then((sentMessage) => {
                    setTimeout(() => {
                        ctx.deleteMessage(sentMessage.message_id);
                    }, 2000); 
                    
                });
                
                setTimeout(() => {
                    ctx.deleteMessage(ctx.message.message_id);
                }, 1000);
            }
        } catch (error) {
            console.log('Error exporting logs:', error);
        }
    } else {
        ctx.reply('?', { reply_to_message_id: ctx.message.message_id }).then((sentMessage) => {
            setTimeout(() => {
                ctx.deleteMessage(sentMessage.message_id);
            }, 1000);
        });
        setTimeout(() => {
            ctx.deleteMessage(ctx.message.message_id);
        }, 1000);
    }
};