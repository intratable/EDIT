import { dirname } from 'path';
import { fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs-extra';
import ini from 'ini';
import {owner} from '../config/config.js'
import {logCommandExecution} from '../bot/log.js'
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const listConfig = async () => {
    const configFilePath = path.join(__dirname, '../config/config.ini');
    try {
        if (await fs.pathExists(configFilePath)) {
            const fileContents = await fs.readFile(configFilePath, 'utf-8');
            const config = ini.parse(fileContents);
            return config;
        } else {
            return null;
        }
    } catch (error) {
        console.log('Error: ', error);
        return null;
    }
};

export const setConfigValue = async (ctx, key) => {
    const configFilePath = path.join(__dirname, '../config/config.ini');

    try {
        let config = {};
        if (await fs.pathExists(configFilePath)) {
            const fileContents = await fs.readFile(configFilePath, 'utf-8');
            config = ini.parse(fileContents);
        }

        if (config[key] === 'off') {
            config[key] = 'on'; 
        } else {
            config[key] = 'off'; 
        }

        await fs.writeFile(configFilePath, ini.stringify(config));
        ctx.reply('✅', { reply_to_message_id: ctx.message.message_id }).then((sentMessage) => {
            setTimeout(() => {
                ctx.deleteMessage(sentMessage.message_id);
            }, 2000); 
        });

        setTimeout(() => {
            ctx.deleteMessage(ctx.message.message_id);
        }, 1000);
    } catch (error) {
        console.log('Error: ', error);
    }
};

export const setiepdfmain =  async (ctx) => {
    if (ctx.from.username === owner) {
        setConfigValue(ctx, 'IEPDF');
        logCommandExecution(ctx, 'set');
    } else {
        ctx.reply('?', { reply_to_message_id: ctx.message.message_id }).then((sentMessage) => {
            setTimeout(() => {
                ctx.deleteMessage(sentMessage.message_id);
            }, 1000);
        });
        setTimeout(() => {
            ctx.deleteMessage(ctx.message.message_id);
        }, 1000);
    }
}

export const setfoto =  async (ctx) => {
    if (ctx.from.username === owner) {
        setConfigValue(ctx, 'FOTO');
        logCommandExecution(ctx, 'set');
    } else {
        ctx.reply('?', { reply_to_message_id: ctx.message.message_id }).then((sentMessage) => {
            setTimeout(() => {
                ctx.deleteMessage(sentMessage.message_id);
            }, 1000);
        });
        setTimeout(() => {
            ctx.deleteMessage(ctx.message.message_id);
        }, 1000);
    }
}

export const setiecelmain =  async (ctx) => {
    if (ctx.from.username === owner) {
        setConfigValue(ctx, 'IECEL');
        logCommandExecution(ctx, 'set');
    } else {
        ctx.reply('?', { reply_to_message_id: ctx.message.message_id }).then((sentMessage) => {
            setTimeout(() => {
                ctx.deleteMessage(sentMessage.message_id);
            }, 1000);
        });
        setTimeout(() => {
            ctx.deleteMessage(ctx.message.message_id);
        }, 1000);
    }
}


export const setrsmain = async (ctx) => {
    if (ctx.from.username === owner) {
        setConfigValue(ctx, 'RS');
        logCommandExecution(ctx, 'set');
    } else {
        ctx.reply('?', { reply_to_message_id: ctx.message.message_id }).then((sentMessage) => {
            setTimeout(() => {
                ctx.deleteMessage(sentMessage.message_id);
            }, 1000);
        });
        setTimeout(() => {
            ctx.deleteMessage(ctx.message.message_id);
        }, 1000);
    }
}

export const setenamain = async (ctx) => {
    if (ctx.from.username === owner) {
        setConfigValue(ctx, 'ENACOM');
        logCommandExecution(ctx, 'set');
    } else {
        ctx.reply('?', { reply_to_message_id: ctx.message.message_id }).then((sentMessage) => {
            setTimeout(() => {
                ctx.deleteMessage(sentMessage.message_id);
            }, 1000);
        });
        setTimeout(() => {
            ctx.deleteMessage(ctx.message.message_id);
        }, 1000);
    }
}

export const setdatacelmain = async (ctx) => {
    if (ctx.from.username === owner) {
        setConfigValue(ctx, 'DATACEL');
        logCommandExecution(ctx, 'set');
    } else {
        ctx.reply('?', { reply_to_message_id: ctx.message.message_id }).then((sentMessage) => {
            setTimeout(() => {
                ctx.deleteMessage(sentMessage.message_id);
            }, 1000);
        });
        setTimeout(() => {
            ctx.deleteMessage(ctx.message.message_id);
        }, 1000);
    }
}

export const setlist = async (ctx) => {
    if (ctx.from.username === owner) {
        const config = await listConfig();
        if (config) {
            let response = '\n';
            for (const key in config) {
                response += `${key} = ${config[key]}\n`;
            }
            ctx.reply(response);
        } else {
            ctx.reply('No se pudo encontrar el archivo config.ini.');
        }
    } else {
        ctx.reply('?', { reply_to_message_id: ctx.message.message_id }).then((sentMessage) => {
            setTimeout(() => {
                ctx.deleteMessage(sentMessage.message_id);
            }, 1000);
        });
        setTimeout(() => {
            ctx.deleteMessage(ctx.message.message_id);
        }, 1000);
    }
    }