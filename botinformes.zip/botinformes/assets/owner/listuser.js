import fs from 'fs-extra';
import path from 'path';
import { dirname } from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

export const listUsers = async (ctx) => {
    try {
        const dataDir = path.join(__dirname, '../../data');
        const users = [];

        if (fs.existsSync(dataDir)) {
            const userDirs = fs.readdirSync(dataDir);

            userDirs.forEach(userId => {
                const userFile = path.join(dataDir, userId, `${userId}.json`);
                if (fs.existsSync(userFile)) {
                    const userData = fs.readFileSync(userFile, 'utf8');
                    const { userId, userAt, MEMB, SALDO } = JSON.parse(userData);
                    users.push({ userId, userAt, MEMB, SALDO });
                }
            });
        }

        if (users.length > 0) {
            let response = '\n\n';
            users.forEach(user => {
                const membStatus = user.MEMB === 1 ? 'ON' : 'OFF';
                response += `${user.userId} - @${user.userAt} || ${membStatus} - ${user.SALDO}\n`;
            });
            ctx.reply(response);
        } 
    } catch (error) {
        console.log('Error listing users:', error);
    }
};
