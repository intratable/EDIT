import { dirname } from 'path';
import { fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs-extra';
import { owner } from '../config/config.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

export const upgradeMembership = async (ctx, userId, saldo) => {
    const dir = path.join(__dirname, '../../data', String(userId));
    const file = path.join(dir, `${userId}.json`);
    
    try {
        if (await fs.pathExists(file)) {
            const userData = await fs.readJson(file);
            userData.MEMB = 1;
            userData.SALDO = saldo;
            await fs.writeJson(file, userData);
            ctx.reply('✅', { reply_to_message_id: ctx.message.message_id }).then((sentMessage) => {
                setTimeout(() => {
                    ctx.deleteMessage(sentMessage.message_id);
                }, 2000);
            });
            
            setTimeout(() => {
                ctx.deleteMessage(ctx.message.message_id);
            }, 1000);
        } else {
            ctx.reply('❌', { reply_to_message_id: ctx.message.message_id }).then((sentMessage) => {
                setTimeout(() => {
                    ctx.deleteMessage(sentMessage.message_id);
                }, 2000);
            });
            
            setTimeout(() => {
                ctx.deleteMessage(ctx.message.message_id);
            }, 1000);
        }
    } catch (error) {
        ctx.reply('❌', { reply_to_message_id: ctx.message.message_id }).then((sentMessage) => {
            setTimeout(() => {
                ctx.deleteMessage(sentMessage.message_id);
            }, 2000);
        });
        
        setTimeout(() => {
            ctx.deleteMessage(ctx.message.message_id);
        }, 1000);
    }
};

export const upmain = async (ctx) => {
    const [command, userId, saldoString] = ctx.message.text.split(' ');
    const saldo = Number(saldoString);

    if (ctx.from.username === owner) {
        if (userId && !isNaN(saldo)) {
            await upgradeMembership(ctx, userId, saldo);
        } else {
            console.log('Provide valid ID and numeric saldo.');
        }
    } else {
        ctx.reply('?', { reply_to_message_id: ctx.message.message_id }).then((sentMessage) => {
            setTimeout(() => {
                ctx.deleteMessage(sentMessage.message_id);
            }, 1000);
        });
        setTimeout(() => {
            ctx.deleteMessage(ctx.message.message_id);
        }, 1000);
    }
};
