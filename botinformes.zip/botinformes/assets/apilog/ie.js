import { dirname } from 'path';
import { fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs-extra';
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const folderPath = `${__dirname}/server/ext/`;
const filePath = `${folderPath}/logie.json`;
import {owner} from '../config/config.js'

const readJsonFile = () => {
    if (fs.existsSync(filePath)) {
        const rawData = fs.readFileSync(filePath);
        return JSON.parse(rawData);
    }
    return [];
};

const writeJsonFile = (data) => {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
};

export const addlogie = async (ctx) => {
    if (ctx.from.username === owner) {
        const messageText = ctx.message.text;
        const args = messageText.split(' ');

        if (args.length !== 3) {
            return ctx.reply('Uso: /add user pass');
        }

        const user = args[1];
        const pass = args[2];

        const newEntry = {
            id: Date.now(), // Usar el timestamp como ID único
            user: user,
            password: pass
        };

        if (!fs.existsSync(folderPath)) {
            fs.mkdirSync(folderPath, { recursive: true });
        }

        let data = readJsonFile();
        data.push(newEntry);
        writeJsonFile(data);

        ctx.reply('Datos añadidos correctamente.');
    } else {
        ctx.reply('?', { reply_to_message_id: ctx.message.message_id }) .then((sentMessage) => {
            setTimeout(() => {
                ctx.deleteMessage(sentMessage.message_id);
            }, 1000); 
            
        });
        setTimeout(() => {
            ctx.deleteMessage(ctx.message.message_id);
        }, 1000);
    }
}

export const listlogie =  async (ctx) => {
    if (ctx.from.username === owner) {
        let data = readJsonFile();
        if (data.length === 0) {
            return ctx.reply('No hay datos disponibles.');
        }

        let response = 'ID - User\n';
        data.forEach((entry, index) => {
            response += `${index + 1} - ${entry.user}\n`;
        });

        ctx.reply(response);
    } else {
        ctx.reply('?', { reply_to_message_id: ctx.message.message_id }) .then((sentMessage) => {
            setTimeout(() => {
                ctx.deleteMessage(sentMessage.message_id);
            }, 1000); 
            
        });
        setTimeout(() => {
            ctx.deleteMessage(ctx.message.message_id);
        }, 1000);
    }
}

export const dellogie = async (ctx) => {
    if (ctx.from.username === owner) {
        const messageText = ctx.message.text;
        const args = messageText.split(' ');

        if (args.length !== 2) {
            return ctx.reply('Uso: /delete id');
        }

        const id = parseInt(args[1], 10);

        let data = readJsonFile();
        if (id < 1 || id > data.length) {
            return ctx.reply('ID no válido.');
        }

        data.splice(id - 1, 1);
        writeJsonFile(data);

        ctx.reply('Datos eliminados correctamente.');
    } else {
        ctx.reply('?', { reply_to_message_id: ctx.message.message_id }) .then((sentMessage) => {
            setTimeout(() => {
                ctx.deleteMessage(sentMessage.message_id);
            }, 1000); 
            
        });
        setTimeout(() => {
            ctx.deleteMessage(ctx.message.message_id);
        }, 1000);
    }
}