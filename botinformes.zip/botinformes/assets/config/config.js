export const owner = 'fatgov'
export const TELEGRAM_BOT_TOKEN = '7255534026:AAHKeYg1eLBgSXrXipLTudvpC8F6OudKeSA';

export const ipvps = 'localhost'
export const port = '666'