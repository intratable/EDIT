import axios from 'axios';
import cheerio from 'cheerio';

export async function fetchNosisData(dni) {
    const infoTerceros = 'https://mi.nosis.com/InformeTerceros/RealizarBusqueda';
    const dnis = { query: dni };

    try {
        const response = await axios.post(infoTerceros, dnis);
        const datos = response.data;
        const htmlTabla = datos.HtmlTabla;
        const $ = cheerio.load(htmlTabla);

        const documento = $("div.resultados-doc.align-self-center.col-12.col-sm-3.col-lg-2").text().trim();
        const nombre = $("div.resultados-razon-social.align-self-center.col-12.col-sm-5.col-lg-6").text().trim();

        const direcciones = [];
        const telefonos = [];

        $("div.direccion.float-start").each((i, elem) => {
            const direccionText = $(elem).text().trim();
            direcciones.push(direccionText);

            const telefonoMatch = direccionText.match(/Tel:\s*\[?\d+\]?\s*\d+/g);
            if (telefonoMatch) {
                telefonoMatch.forEach(tel => {
                    telefonos.push(tel.replace('Tel:', '').trim());
                });
            }
        });

        return { documento, nombre, direcciones, telefonos };
    } catch (error) {
        console.error("Error al realizar la solicitud:", error);
        return null;
    }
}