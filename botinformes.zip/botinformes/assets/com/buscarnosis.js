import fetch from 'node-fetch';
import { Telegraf, Markup } from 'telegraf';
import { dirname } from 'path';
import { fileURLToPath } from 'url';
import {port , ipvps} from '../config/config.js'

export const buscarpersonans = async (ctx) => {
    const commandParts = ctx.message.text.split(' ');

    if (commandParts.length < 3 || commandParts.length > 5) {
        ctx.reply('/buscar Apellido Nombre ', { reply_to_message_id: ctx.message.message_id }).then((sentMessage) => {
            setTimeout(() => {
                ctx.deleteMessage(sentMessage.message_id);
            }, 2000);
        });
        return;
    }

    try {
        const url = 'http://' + ipvps + ':' + port + '/buscarnosis';

        const response = fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({info : commandParts.slice(1) , chatId: ctx.chat.id }), 
        });

    } catch (error) {
        console.error('Error en el cliente Telegram:', error);
        ctx.reply('❌');
    }
}
