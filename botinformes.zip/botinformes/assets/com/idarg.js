import fetch from 'node-fetch';
import { Telegraf, Markup } from 'telegraf';
import { port, ipvps } from '../config/config.js';

export const idarpdf = async (bot, ctx, inputNumber, sex, userId) => {
    ctx.reply('🔎').then((sentMessage) => {
        setTimeout(() => {
            ctx.deleteMessage(sentMessage.message_id);
        }, 4000);
});
    try {
        const url = `http://${ipvps}:${port}/idarg417`;
        console.log(`Sending request to ${url} with body: ${JSON.stringify({ dni: inputNumber, gender: sex, chatId: userId })}`);

        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ dni: inputNumber, gender: sex, chatId: userId }),
        });


        const user = await bot.telegram.getChatMember(ctx.chat.id, userId);
        
        ctx.reply(`@${user.user.username}, la foto se te ha enviado por privado.`).then((sentMessage) => {
            setTimeout(() => {
                ctx.deleteMessage(sentMessage.message_id);
            }, 4000);
    });;
  
    } catch (error) {
        console.error('Error en el cliente Telegram:', error);
        ctx.reply('❌');
    }
};
