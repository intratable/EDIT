import fetch from 'node-fetch';
import { port, ipvps } from '../config/config.js';

export const iepdf = async (ctx, inputNumber,userId) => {


  try {
    const url = 'http://' + ipvps + ':' + port + '/iepdf';

    

    const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ info: inputNumber, chatId: userId  }), 
    });

    if (response.ok) {
        const data = await response.json();
        // Procesa y responde con los datos recibidos
        ctx.reply(`Resultado: ${JSON.stringify(data)}`);
    } else {
        ctx.reply('❌ Error en la solicitud.');
    }

} catch (error) {
    console.error('Error en el cliente Telegram:', error);
    ctx.reply('❌');
}
};
