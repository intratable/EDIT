import { Telegraf, Markup, session } from 'telegraf';
import { dirname } from 'path';
import fs from 'fs';
import { calcularCuil } from './cuil.js';
import axios from 'axios';
import cheerio from 'cheerio';
import { fetchNosisData } from './nosisnombretel.js';
function readConfig() {
    const configPath = './assets/config/config.ini';
    const config = fs.readFileSync(configPath, 'utf-8');
    const configLines = config.split('\n');
    const configObject = {};

    configLines.forEach(line => {
        const [key, value] = line.split('=');
        if (key && value) {
            configObject[key.trim()] = value.trim().toLowerCase();
        }
    });

    return configObject;
}

async function fetchData(url) {
    try {
        const response = await fetch(url);
        if (response.status === 200) {
            return await response.json();
        } else {
            return null;
        }
    } catch (error) {
        console.error('Error fetching data:', error);
        return null;
    }
}



export const dnimain = async (ctx) => {
    const config = readConfig();
    const userId = ctx.from.id;
    const ieEnabled = config.IEPDF === 'on';
    const rsEnabled = config.RS === 'on';
    const fotoEnabled = config.FOTO === 'on';

    const commandParts = ctx.message.text.split(' ');

    if (commandParts.length !== 3) {
        ctx.reply(' /dni 10XXXXXX M|F', { reply_to_message_id: ctx.message.message_id }).then((sentMessage) => {
            setTimeout(() => {
                ctx.deleteMessage(sentMessage.message_id);
            }, 2000);
        });
        return;
    }

    const inputNumber = commandParts[1].trim();
    const sex = commandParts[2].trim();

    try {
        const url1 = `https://clientes.credicuotas.com.ar/v1/onboarding/resolvecustomers/${inputNumber}`;
        const url2 = `https://fiscalizar.seguridadvial.gob.ar//api/licencias?numeroDocumento=${inputNumber}&sexo=${sex}`;
        
        const [nosisData, data1, data2] = await Promise.all([
            fetchNosisData(inputNumber),
            fetchData(url1),
            fetchData(url2)
        ]);
        
        let nombreCompleto = '';
        
        if (nosisData && nosisData.nombre) {
            nombreCompleto = nosisData.nombre;
        } 
        
        if (data1 && data1.length > 0 && data1[0].nombrecompleto) {
            nombreCompleto = data1[0].nombrecompleto;
        } 
        
        if (data2 && data2.length > 0 && data2[0].nombre && data2[0].apellido) {
            nombreCompleto = `${data2[0].nombre} ${data2[0].apellido}`;
        }

        // Cálculo del CUIL
        let cuil;
        try {
            cuil = calcularCuil.calcular(inputNumber, sex);
        } catch (error) {
            ctx.reply(error.message, { reply_to_message_id: ctx.message.message_id }).then((sentMessage) => {
                setTimeout(() => {
                    ctx.deleteMessage(sentMessage.message_id);
                }, 2000);
            });
            return;
        }

        const buttons = [];
        if (rsEnabled) {
            buttons.push(Markup.button.callback(`RS`, `RSPDF ${inputNumber} ${userId}`));
        }
        if (ieEnabled) {
            buttons.push(Markup.button.callback(`IE`, `IEPDF ${inputNumber}  ${userId}`));
        }
        if (fotoEnabled) {
            buttons.push(Markup.button.callback(`Foto`, `fotofoto ${inputNumber} ${sex} ${userId}`));
        }

        if (fotoEnabled) {
            buttons.push(Markup.button.callback(`IDARG`, `idarg ${inputNumber} ${sex} ${userId}`));
        }

        if (buttons.length > 0) {
            let replyMessage = `🏴‍☠️\`  𝗚𝗢𝗕𝗕𝗢𝗧.𝗡𝗘𝗧 \`\n\n `;
            if (nombreCompleto) {
                replyMessage += `\`-   ${nombreCompleto}\`\n`;
            }
            

            if (nosisData && nosisData.telefonos && nosisData.telefonos.length > 0) {
                replyMessage += `\n🏚   \`${nosisData.telefonos.join(', ')}\`\n`;
            }
            replyMessage += `\nCUIL  \`${cuil}\``;
            ctx.replyWithMarkdown(replyMessage, Markup.inlineKeyboard(buttons));
        } else {
            ctx.reply('No hay opciones disponibles.', { reply_to_message_id: ctx.message.message_id }).then((sentMessage) => {
                setTimeout(() => {
                    ctx.deleteMessage(sentMessage.message_id);
                }, 1000);
            });
            setTimeout(() => {
                ctx.deleteMessage(ctx.message.message_id);
            }, 1000);
        }
    } catch (error) {
        ctx.reply("Hubo un error al realizar la consulta.");
    }
}
