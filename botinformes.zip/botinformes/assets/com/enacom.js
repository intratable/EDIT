import fetch from 'node-fetch';
import { port, ipvps } from '../config/config.js';

export const enacomsearchmain = async (ctx, inputNumber, inputNumber2) => {
    try {
        const url = 'http://' + ipvps + ':' + port + '/enacom';

        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ area: inputNumber, linea: inputNumber2, chatId: ctx.chat.id }), 
        });
        ctx.reply('🔎', { reply_to_message_id: ctx.message.message_id }).then((sentMessage) => {
            setTimeout(() => {
                ctx.deleteMessage(sentMessage.message_id);
            }, 2000); 
        });

        setTimeout(() => {
            ctx.deleteMessage(ctx.message.message_id);
        }, 1000);

        if (response.ok) {
            const data = await response.json();
            // Procesa y responde con los datos recibidos
            ctx.reply(`Resultado: ${JSON.stringify(data)}`);
        } else {
            ctx.reply('❌ Error en la solicitud.');
        }

    } catch (error) {
        console.error('Error en el cliente Telegram:', error);
        ctx.reply('❌');
    }
};

export const enacomboton = async (ctx) => {
    const inputNumber = ctx.match[1];
    const inputNumber2 = ctx.match[2];
    console.log(inputNumber2)
    await ctx.answerCbQuery();
    enacomsearchmain(ctx, inputNumber, inputNumber2);
}