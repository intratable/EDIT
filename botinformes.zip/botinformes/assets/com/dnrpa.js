import fetch from 'node-fetch';
import { Telegraf, Markup } from 'telegraf';
import { dirname } from 'path';
import { fileURLToPath } from 'url';
import {port , ipvps} from '../config/config.js'

export const dnrpa = async (ctx) => {
    const commandParts = ctx.message.text.split(' ');

    if (commandParts.length < 2 ) {
        return;
    }

    try {
        const url = 'http://' + ipvps + ':' + port + '/dnrpa';

        const response = fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({info : commandParts.slice(1) , chatId: ctx.chat.id }),
        });

    } catch (error) {
        ctx.reply('❌',{ reply_to_message_id: ctx.message.message_id }) .then((sentMessage) => {
            setTimeout(() => {
                ctx.deleteMessage(sentMessage.message_id);
            }, 1000); 
            
        });
        setTimeout(() => {
            ctx.deleteMessage(ctx.message.message_id);
        }, 1000);
    }
}
