import { Telegraf, Markup, session } from 'telegraf';
import { dirname} from 'path';
import fs from 'fs'

function readConfig() {
    const configPath = './assets/config/config.ini';
    const config = fs.readFileSync(configPath, 'utf-8');
    const configLines = config.split('\n');
    const configObject = {};

    configLines.forEach(line => {
        const [key, value] = line.split('=');
        if (key && value) {
            configObject[key.trim()] = value.trim().toLowerCase();
        }
    });

    return configObject;
}

export const vehmain = async (ctx) => {
    const config = readConfig();

    const enacomEnabled = config.DNRPA === 'on';
    const datacelEnabled = config.IEVEH === 'on';

    const commandParts = ctx.message.text.split(' ');

    if (commandParts.length !== 2) {
        ctx.reply(' /veh 10XXXXXX ', { reply_to_message_id: ctx.message.message_id }).then((sentMessage) => {
            setTimeout(() => {
                ctx.deleteMessage(sentMessage.message_id);
            }, 2000);
        });
        return;
    }

    const inputNumber = commandParts[1].trim();

    const buttons = [];
    if (enacomEnabled) {
        buttons.push(Markup.button.callback(`Titular`, `IEVEH ${inputNumber}`));
    }
    if (ieEnabled) {
        buttons.push(Markup.button.callback(`DNRPA `, `DNRPA ${inputNumber}`));
    }

    if (buttons.length > 0) {
        ctx.reply('Seleccione una opción:', Markup.inlineKeyboard(buttons));
    } else {
        ctx.reply('No hay opciones disponibles.',{ reply_to_message_id: ctx.message.message_id }) .then((sentMessage) => {
            setTimeout(() => {
                ctx.deleteMessage(sentMessage.message_id);
            }, 1000); 
            
        });
        setTimeout(() => {
            ctx.deleteMessage(ctx.message.message_id);
        }, 1000);
    }
}