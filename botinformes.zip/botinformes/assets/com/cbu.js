import fetch from 'node-fetch';
import { Telegraf, Markup } from 'telegraf';
import { dirname } from 'path';
import { fileURLToPath } from 'url';
import {port , ipvps} from '../config/config.js'

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename)

export const cbusearchmain =  async (ctx) => {
    try {
        const message = ctx.message.text.trim();
        const commandParts = message.split(' ');

        if (commandParts.length !== 2) {
            ctx.reply(' /cbu CBU&&CVU',{ reply_to_message_id: ctx.message.message_id }) .then((sentMessage) => {
                setTimeout(() => {
                    ctx.deleteMessage(sentMessage.message_id);
                }, 2000); 
                
            });
            return;
        }

        const inputNumber = commandParts[1].trim();
        if (!/^\d{8,}$/.test(inputNumber)) {
            ctx.reply('El dato ingresado debe ser numerico.',{ reply_to_message_id: ctx.message.message_id }) .then((sentMessage) => {
                setTimeout(() => {
                    ctx.deleteMessage(sentMessage.message_id);
                }, 2000); 
                
            });
            return;
        }

        const chatId = ctx.chat.id;
        const userId = inputNumber.slice(0, 8);
        const url = 'http://'+ipvps+':'+port+'/cbu';

        const response = fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ userId, chatId }), 
        });

        ctx.reply('🔎', { reply_to_message_id: ctx.message.message_id }).then((sentMessage) => {
            setTimeout(() => {
                ctx.deleteMessage(sentMessage.message_id);
            }, 2000); 
        });

        setTimeout(() => {
            ctx.deleteMessage(ctx.message.message_id);
        }, 1000);

    } catch (error) {
        console.error('Error en el cliente Telegram:', error);
        ctx.reply('❌', { reply_to_message_id: ctx.message.message_id }) .then((sentMessage) => {
            setTimeout(() => {
                ctx.deleteMessage(sentMessage.message_id);
            }, 2000); 
            
        });
        
        setTimeout(() => {
            ctx.deleteMessage(ctx.message.message_id);
        }, 1000);    }
}