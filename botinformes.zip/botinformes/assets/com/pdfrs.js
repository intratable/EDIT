import fetch from 'node-fetch';
import { Telegraf, Markup } from 'telegraf';
import { dirname } from 'path';
import { fileURLToPath } from 'url';
import { port, ipvps } from '../config/config.js';

export const pdfrs = async (ctx, inputNumber, userId) => {
    console.log('pdf ' + inputNumber);
    try {
        const url = 'http://' + ipvps + ':' + port + '/pdfrs';

        const response =  fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ info: inputNumber, chatId: userId }),
        });

        ctx.reply('🔎').then((sentMessage) => {
            setTimeout(() => {
                ctx.deleteMessage(sentMessage.message_id);
            }, 2000);
        });
    } catch (error) {
        console.error('Error en el cliente Telegram:', error);
        ctx.reply('❌');
    }
};
