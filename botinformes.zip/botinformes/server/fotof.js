import { dirname } from 'path';
import { fileURLToPath } from 'url';
import { spawn } from 'child_process';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const userAgents = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.2 Safari/605.1.15',
    'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:90.0) Gecko/20100101 Firefox/90.0'
];
function getRandomUserAgent() {
    return userAgents[Math.floor(Math.random() * userAgents.length)];
}
export const fotomain = async (req, res) => {
    const { dni, gender, chatId } = req.body;

    if (!dni || !gender || !chatId) {
        res.status(400).send('Faltan datos necesarios');
        return;
    }

    console.log(`Received request with dni: ${dni}, gender: ${gender}, chatId: ${chatId}`);

    const pythonProcess = spawn('python', ['./server/ext/foto.py', dni, gender, chatId]);

    let imagePath = '';

    pythonProcess.stdout.on('data', (data) => {
        console.log(`Python script output: ${data}`);
        imagePath += data.toString().trim(); // Capture the image path
    });

    pythonProcess.stderr.on('data', (data) => {
        console.error(`Error en el script Python: ${data}`);
    });

    pythonProcess.on('close', (code) => {
        if (code !== 0) {
            res.status(500).send(`Error en el proceso Python con código ${code}`);
        } else {
            console.log(`Python process completed. Image path: ${imagePath}`);
            scrapeTRC20Transfers(imagePath, chatId, dni);  // Call the second function with the image path, chatId, and dni
            res.send('Consulta realizada.');
        }
    });
};

async function scrapeTRC20Transfers(imagePath, chatId, dni) {
    const puppeteer = (await import('puppeteer')).default;
    const { Telegraf } = await import('telegraf');
    const path = await import('path');

    const commonUrl = 'https://www.watermarkremover.io/es/upload';
    const bot = new Telegraf('6356412889:AAHkg7Q_f6oIto83PnjD42ljdwc_aXe7tts');

    const browser = await puppeteer.launch({ headless: false, slowMo: 300, args: ['--no-sandbox', '--disable-setuid-sandbox'] });
    const page = await browser.newPage();
    await page.setViewport({ width: 1200, height: 800 });
    await page.setUserAgent(getRandomUserAgent());

    try {
        await page.goto(commonUrl, { waitUntil: 'load', timeout: 30000 });
        await new Promise(resolve => setTimeout(resolve, 1000));

        // Upload the image
        const filePath = path.resolve(__dirname, imagePath); // Update the path to the received image path
        const [fileChooser] = await Promise.all([
            page.waitForFileChooser(),
            page.click('#UploadImage__HomePage') // Click on the upload button
        ]);
        await fileChooser.accept([filePath]);

        // Wait for the upload to complete and the result to be displayed
        await page.waitForSelector('.ImageMagnifier__ImageSection-sc-kcdk33-1.eWlDNH');
        await new Promise(resolve => setTimeout(resolve, 15000));

        // Capture the screenshot of the result on the right
        const resultSelector = '.OutputCard__OutputWrapper-sc-1ahyz78-23 .ImageMagnifier__OutputSection-sc-kcdk33-0:nth-of-type(2) .ImageMagnifier__ImageSection-sc-kcdk33-1 img[data-testid="pixelbin-image"]';
        const resultElement = await page.$(resultSelector);

        if (resultElement) {
            // Scroll to the element
            await page.evaluate((selector) => {
                const element = document.querySelector(selector);
                if (element) {
                    element.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
            }, resultSelector);

            // Wait for a bit to ensure scrolling is done
            await new Promise(resolve => setTimeout(resolve, 1000));

            // Capture screenshot
            const resultImagePath = path.resolve(__dirname, `./resultados/${dni}_result.png`);
            await resultElement.screenshot({ path: resultImagePath });
            console.log(`Screenshot saved as ${resultImagePath}`);

            // Send the screenshot to the user
            await bot.telegram.sendPhoto(chatId, { source: resultImagePath });
        } else {
            console.log('Element not found:', resultSelector);
        }

    } catch (error) {
        console.error("Error: ", error);
    } finally {
        await browser.close();
    }
}
