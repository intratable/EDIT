import express from 'express';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';
import { exec, spawn } from 'child_process';
import {TELEGRAM_BOT_TOKEN} from '../assets/config/config.js'

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

export const cbusearch = async (req, res) => {
    try {
        const { userId } = req.body;
        const chatidmain = req.body.chatId;  
        const userMainDirscr = join(__dirname, './ext', 'cbu.py');
        const comm = 'python';
        const args = [
            userMainDirscr,
            userId 
        ];
        const pythonProcess = spawn(comm, args);
        let responseData = '';
        pythonProcess.stdout.on('data', (data) => {
            console.log(`Python script output: ${data}`);
            responseData += data.toString()
            const messageToSend = '🏴‍☠️ : '+ responseData
            const botToken = TELEGRAM_BOT_TOKEN;
            const chatId = chatidmain;
            const telegramUrl = `https://api.telegram.org/bot${botToken}/sendMessage`;
            const telegramParams = {
                chat_id: chatId,
                text: messageToSend
            };
            fetch(telegramUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(telegramParams),
            }).then(() => {
                console.log('Mensaje enviado al bot de Telegram.');
            }).catch((err) => {
                console.error('Error al enviar mensaje al bot de Telegram:', err);
            });
        });
        pythonProcess.stderr.on('data', (data) => {
            console.error(`Error en el script Python: ${data}`);
        });
        pythonProcess.on('close', (code) => {
            console.log(`Proceso de Python cerrado con código ${code}`);        
        });
    } catch (error) {
        console.error(error);
        res.status(500).send('Error occurred while processing /search');
    }
  }