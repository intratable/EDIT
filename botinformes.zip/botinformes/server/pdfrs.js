import { dirname, join } from 'path';
import { fileURLToPath } from 'url';
import { spawn } from 'child_process';
import fetch from 'node-fetch';
import fs from 'fs';
import FormData from 'form-data';
import { TELEGRAM_BOT_TOKEN } from '../assets/config/config.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

export const pdfrsmain = async (req, res) => {
    try {
        const { info, chatId } = req.body;

        if (!info || !chatId) {
            res.status(400).send('Faltan datos necesarios');
            return;
        }

        console.log(`DNI recibido: ${info}, Chat ID: ${chatId}`);
        
        const pdfFilePath = join(__dirname, './datapdfrs', `${info}_informe.pdf`);

        const sendPDF = async (filePath) => {
            console.log(`Enviando PDF desde la ruta: ${filePath}`);
            const telegramUrl = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendDocument`;

            const formData = new FormData();
            formData.append('chat_id', chatId);
            formData.append('document', fs.createReadStream(filePath));

            try {
                const response = await fetch(telegramUrl, {
                    method: 'POST',
                    body: formData,
                });

                const responseBody = await response.json();
                if (!response.ok) {
                    throw new Error(`Error al enviar mensaje al bot de Telegram: ${responseBody.description}`);
                }

            } catch (err) {
                res.status(500).send('Error occurred while sending PDF to Telegram.');
            }
        };

        if (fs.existsSync(pdfFilePath)) {
            await sendPDF(pdfFilePath);
            return;
        }

        const scriptPath = join(__dirname, './ext', 'rspdf.py');
        const pythonProcess = spawn('python', [scriptPath, info]);

        let responseData = '';

        pythonProcess.stdout.on('data', (data) => {
            responseData += data.toString();
        });

        pythonProcess.stderr.on('data', (data) => {
            console.error(`Error en el script Python: ${data}`);
        });

        pythonProcess.on('close', async (code) => {

            const lines = responseData.trim().split('\n');
            const generatedPdfFilePath = lines[lines.length - 1];

            console.log(`Verificando la existencia del archivo generado: ${generatedPdfFilePath}`);
            if (fs.existsSync(generatedPdfFilePath)) {
                await sendPDF(generatedPdfFilePath);
            } else {
                console.error('PDF no encontrado después de ejecutar el script Python.');
            }
        });
    } catch (error) {
        console.error(error);
    }
};
