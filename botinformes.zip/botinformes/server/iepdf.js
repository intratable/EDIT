import { dirname, join } from 'path';
import { fileURLToPath } from 'url';
import { spawn } from 'child_process';
import { TELEGRAM_BOT_TOKEN } from '../assets/config/config.js';
import fetch from 'node-fetch';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

export const pdfiemain = async (req, res) => {
  try {
    const info = req.body.info;
    const chatId = req.body.chatId;
    console.log(chatId)
    if (!info || info.length < 1) {
      res.status(400).send('Faltan datos necesarios');
      return;
    }

    const dni = info;
    const userMainDirscr = join(__dirname, './ext', 'iepdf.py');
    const comm = 'python';
    const args = [userMainDirscr, dni];
    const pythonProcess = spawn(comm, args);
    let responseData = '';

    pythonProcess.stdout.on('data', (data) => {
      console.log(`Python script output: ${data}`);
      responseData += data.toString();
    });

    pythonProcess.stderr.on('data', (data) => {
      console.error(`Error en el script Python: ${data}`);
    });

    pythonProcess.on('close', async (code) => {
      console.log(`Proceso de Python cerrado con código ${code}`);

      const messageToSend = '🏴‍☠️ :' + responseData;
      const botToken = TELEGRAM_BOT_TOKEN;
      const telegramUrl = `https://api.telegram.org/bot${botToken}/sendMessage`;
      const telegramParams = {
        chat_id: chatId,
        text: messageToSend
      };

      try {
        await fetch(telegramUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(telegramParams),
        });
        console.log('Mensaje enviado al bot de Telegram.');
      } catch (err) {
        console.error('Error al enviar mensaje al bot de Telegram:', err);
      }

      res.status(200).send('Proceso completado');
    });
  } catch (error) {
    console.error(error);
    res.status(500).send('Error occurred while processing /iepdf');
  }
};
