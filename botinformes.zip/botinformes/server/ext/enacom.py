import requests
import asyncio
from capmonstercloudclient import CapMonsterClient, ClientOptions
from capmonstercloudclient.requests import RecaptchaV2ProxylessRequest
from bs4 import BeautifulSoup
import sys

numnum = sys.argv[1]

client_options = ClientOptions(api_key="f8359ff3743bf3fa23deb398a12e000d")
cap_monster_client = CapMonsterClient(options=client_options)

async def solve_captcha(websiteUrl, websiteKey):
    return (await cap_monster_client.solve_captcha(RecaptchaV2ProxylessRequest(websiteUrl=websiteUrl,
                                                websiteKey=websiteKey)))["gRecaptchaResponse"]

async def main():

    captcha_response = await solve_captcha("https://numeracion.enacom.gob.ar/", "6LedALcZAAAAAHU1V19R1dnelvkcFWD9G8OFhvI-")

    data = {
        "__EVENTTARGET": "",
        "__EVENTARGUMENT": "",
        "__VIEWSTATE": "/wEPDwUKLTc1MDc1NDYzN2RkdxCJRT+HvycdQ656voID7+kFE6wBhJpP653PJ5yQdEo=",
        "__VIEWSTATEGENERATOR": "FF063A21",
        "__EVENTVALIDATION": "/wEdAAY0eTEmPNG8hn/eJYEfKAiVgV5mcWndSyRSUZxID3LtEMk87fsD+R/UJSJEK5Oe+Hbo3XongM2edh0XFBcIW0tCOnp2d3o2yCsfh4UOuA8OB697VcdJwF1MHeOWbrJ+eM3NP7yAQngIlSd+gRXyJCqTMeWJ0qsA1lm0WEwxq+HWYQ==",
        "ctl00$MainContent$TxtNumero": numnum,
        "g-recaptcha-response": captcha_response,
        "ctl00$MainContent$BtnBuscar": "Buscar"
    }

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:127.0) Gecko/20100101 Firefox/127.0",
        "Content-Type": "application/x-www-form-urlencoded",
        "Referer": "https://numeracion.enacom.gob.ar/",
        "Cookie": "_ga_5HJXZ33Y39=GS1.1.1718767453.2.0.1718767946.0.0.0; _ga=GA1.1.1171461531.1718033233; _gid=GA1.3.674063616.1718738985; ASP.NET_SessionId=cjg04ckshtjgcipvaehpcy1m"
    }


    response = requests.post("https://numeracion.enacom.gob.ar/", data=data, headers=headers)

    soup = BeautifulSoup(response.text, 'html.parser')

    prestador_original = soup.find('input', {'id': 'MainContent_TxtPrestadorOriginal'}).get('value', '')
    prestador_actual = soup.find('input', {'id': 'MainContent_TxtPrestadorActual'}).get('value', '')

    print(" ", prestador_original)
   

asyncio.run(main())
