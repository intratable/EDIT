import asyncio
import requests
from capmonstercloudclient import CapMonsterClient, ClientOptions
from capmonstercloudclient.requests import RecaptchaV2ProxylessRequest
import sys

usermain = "alzogarayyasoc" #"estudiojdrossi"
passw ="35364136estudio" #"Bocajuniors21"

data = " ".join(sys.argv[1:])
print(data)
client_options = ClientOptions(api_key="f8359ff3743bf3fa23deb398a12e000d")
cap_monster_client = CapMonsterClient(options=client_options)

async def solve_captcha(website_url, website_key):
    return (await cap_monster_client.solve_captcha(RecaptchaV2ProxylessRequest(websiteUrl=website_url,
                                                                               websiteKey=website_key)))["gRecaptchaResponse"]

def get_cookies():

    url = "https://informe.riesgoonline.com/"
    session = requests.Session()
    session.get(url)  
    return session.cookies, session

def check_credentials(session, cookies, username, password):

    website_url = "https://informe.riesgoonline.com/login"
    website_key = "6Lf9KfUmAAAAAL6Fvrs2UBpkBYEUC78_eZtfaPZb"  

    g_recaptcha_response = asyncio.run(solve_captcha(website_url, website_key))

    payload = {
        "username": username,
        "password": password,
        "g-recaptcha-response": g_recaptcha_response
    }

    response = session.post("https://informe.riesgoonline.com/api/usuarios/sesion", data=payload, cookies=cookies)

    if response.status_code == 200 and "usuario_codigo" in response.json():
        return True
    return False

def get_total_pages(session, cookies, dni):
    search_url = f"https://informe.riesgoonline.com/api/informes?pagina=1&buscar={dni}&buscar_tipo=&buscar_sexo=&buscar_edad_desde=&buscar_edad_hasta=&buscar_provincia=&buscar_historico=C&buscar_avanzada="
    response = session.get(search_url, cookies=cookies)
    if response.status_code == 200:
        data = response.json()
        return data["paginas"]
    return 0

def search_person_all_pages(session, cookies, dni):
    total_pages = get_total_pages(session, cookies, dni)
    if total_pages == 0:
       
        return

    url_base = "https://informe.riesgoonline.com/api/informes"
    for pagina in range(1, total_pages + 1):
        search_url = f"{url_base}?pagina={pagina}&buscar={dni}&buscar_tipo=&buscar_sexo=&buscar_edad_desde=&buscar_edad_hasta=&buscar_provincia=&buscar_historico=C&buscar_avanzada="
        response = session.get(search_url, cookies=cookies)
        if response.status_code == 200:
            data = response.json()
            for resultado in data["resultado"]:
                print(f"CUIL: {resultado['cuit']} - Nombre: {resultado['nombre']} - Edad: {resultado['edad']}")
        else:
            print(f"Failed to fetch page {pagina}")


cookies, session = get_cookies()
if check_credentials(session, cookies, usermain, passw):
    search_person_all_pages(session, cookies, data)
