import asyncio
import requests
from capmonstercloudclient import CapMonsterClient, ClientOptions
from capmonstercloudclient.requests import RecaptchaV2ProxylessRequest
import time
import sys
import os

dni = sys.argv[1]
usermain = "alzogarayyasoc"
passw = "35364136estudio"
client_options = ClientOptions(api_key="f8359ff3743bf3fa23deb398a12e000d")
cap_monster_client = CapMonsterClient(options=client_options)

async def solve_captcha(website_url, website_key):
    return (await cap_monster_client.solve_captcha(RecaptchaV2ProxylessRequest(websiteUrl=website_url,
                                                                               websiteKey=website_key)))["gRecaptchaResponse"]

def get_cookies():
    url = "https://informe.riesgoonline.com/"
    session = requests.Session()
    session.get(url)
    print("Cookies obtenidas")
    return session.cookies, session

def check_credentials(session, cookies, username, password):
    start_time = time.time()
    website_url = "https://informe.riesgoonline.com/login"
    website_key = "6Lf9KfUmAAAAAL6Fvrs2UBpkBYEUC78_eZtfaPZb"

    g_recaptcha_response = asyncio.run(solve_captcha(website_url, website_key))

    payload = {
        "username": username,
        "password": password,
        "g-recaptcha-response": g_recaptcha_response
    }

    response = session.post("https://informe.riesgoonline.com/api/usuarios/sesion", data=payload, cookies=cookies)
    print(f"Intento de login: {response.status_code}")
    print("Login Response:", response.status_code, response.json())

    end_time = time.time()
    print(f"Login tardó {end_time - start_time:.2f} segundos")

    if response.status_code == 200 and "usuario_codigo" in response.json():
        print("Login exitoso")
        return True
    print("Login fallido")
    return False

def search_person(session, cookies, dni):
    start_time = time.time()
    search_url = f"https://informe.riesgoonline.com/api/informes?pagina=1&buscar={dni}&buscar_tipo=&buscar_sexo=&buscar_edad_desde=&buscar_edad_hasta=&buscar_provincia=&buscar_historico=C&buscar_avanzada="
    response = session.get(search_url, cookies=cookies)
    print(f"Búsqueda de persona: {response.status_code}")
    
    print("Search Response:", response.status_code, response.json())
    
    end_time = time.time()
    print(f"Búsqueda de persona tardó {end_time - start_time:.2f} segundos")
    
    if response.status_code == 200 and response.json().get("resultado"):
        first_result_cuit = response.json()["resultado"][0]["cuit"]
        print(f"Persona encontrada: CUIT {first_result_cuit}")
        return first_result_cuit
    print("No se encontró ningún resultado")
    return None

def request_informe(session, cookies, cuit):
    start_time = time.time()
    request_url = f"https://informe.riesgoonline.com/api/informes/solicitar/{cuit}"
    response = session.get(request_url, cookies=cookies)
    print(f"Solicitud de informe: {response.status_code}")
    
    try:
        response_json = response.json()
        print("Request Informe Response:", response.status_code, response_json)
    except ValueError:
        print("Request Informe Response (Not JSON):", response.status_code, response.text)

    end_time = time.time()
    print(f"Solicitud de informe tardó {end_time - start_time:.2f} segundos")
    
    return response.status_code == 200

def select_and_download_report(session, cookies, cuit):
    start_time = time.time()
    download_url = f"https://informe.riesgoonline.com/api/informes/descargar/{cuit}?opciones[]=contenidos&opciones[]=modulos&opciones[]=adjuntos&opciones[]=graficos"
    response = session.get(download_url, cookies=cookies, stream=True)
    print(f"Descargando informe: {response.status_code}")
    
    if response.status_code == 200:
        os.makedirs("./datapdfrs", exist_ok=True)
        file_path = f"./datapdfrs/{cuit}_informe.pdf"
        with open(file_path, "wb") as file:
            file.write(response.content)
        print(file_path)
        print(f"Informe descargado: {file_path}")
        return file_path
    else:
        print("Error al descargar el informe.")
        return None
    
    end_time = time.time()
    print(f"Descarga del informe tardó {end_time - start_time:.2f} segundos")

cookies, session = get_cookies()

if check_credentials(session, cookies, usermain, passw):
    cuit = search_person(session, cookies, dni)
    if cuit:
        if request_informe(session, cookies, cuit):
            print("Esperando a que se complete la solicitud del informe...")
            file_path = select_and_download_report(session, cookies, cuit)
            if file_path:
                print(f"Archivo descargado: {file_path}")
                print(file_path)  # Imprimir la ruta del archivo PDF generado
        else:
            print("Error al solicitar el informe")
    else:
        print("No se encontró ningún resultado")
else:
    print("Error al iniciar sesión")

session.close()
