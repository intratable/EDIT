import requests
from bs4 import BeautifulSoup
import sys

inputcbu = sys.argv[1]
url_get = 'https://www.datacels.com/cbu'

session = requests.Session()

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3',
}

response_get = session.get(url_get, headers=headers)
soup = BeautifulSoup(response_get.text, 'html.parser')

token_input = soup.find('input', {'name': '_token'})
if token_input:
    token = token_input['value']
else:
    print("No se encontró el token CSRF en la respuesta HTML.")
    print("Contenido HTML recibido:")
    print(response_get.text)
    raise SystemExit("El token CSRF no se pudo obtener. Verifica la estructura de la página.")

cookies = session.cookies.get_dict()

#print("Token CSRF:", token)
#print("Cookies:", cookies)

url_post = 'https://www.datacels.com/cbu'
data = {
    'cbu': inputcbu,
    '_token': token
}

headers_post = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3',
    'Referer': url_get 
}

response_post = session.post(url_post, headers=headers_post, data=data)

soup = BeautifulSoup(response_post.text, 'html.parser')

def get_value(soup, label_text):
    label = soup.find('label', text=label_text)
    if label:
        return label.find_next('br').next_sibling.strip()
    else:
        return None

operador = get_value(soup, 'Banco')

print(operador)