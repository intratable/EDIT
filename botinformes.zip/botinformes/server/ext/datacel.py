import requests
from bs4 import BeautifulSoup
import sys

area = sys.argv[1]
linea = sys.argv[2]

url_get = 'https://www.datacels.com/detectar-empresa-telefono'

session = requests.Session()

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 11.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3',
}

response_get = session.get(url_get, headers=headers)
soup = BeautifulSoup(response_get.text, 'html.parser')

token_input = soup.find('input', {'name': '_token'})
if token_input:
    token = token_input['value']
else:
    raise SystemExit("El token CSRF no se pudo obtener. Verifica la estructura de la página.")

cookies = session.cookies.get_dict()

headers.update({
    'Content-Type': 'application/x-www-form-urlencoded',
    'Referer': url_get,
})

payload = {
    'indicativo':area,
    'bloque': linea,
    '_token': token,
    'buscador': 'Buscar',
}


response_post = session.post(url_get, headers=headers, data=payload)
soup = BeautifulSoup(response_post.text, 'html.parser')

def get_value(soup, label_text):
    label = soup.find('label', text=label_text)
    if label:
        return label.find_next('br').next_sibling.strip()
    else:
        return None

linea = get_value(soup, 'Línea')
operador = get_value(soup, 'Operador')
localidad = get_value(soup, 'Localidad')
servicios = get_value(soup, 'Servicios')


print(" ", operador)
print("Localidad : ", localidad)
print("Servicios : " , servicios)