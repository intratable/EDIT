import requests
import base64
from io import BytesIO
from PIL import Image
from telebot import TeleBot
import sys
import os

bot = TeleBot("7255534026:AAHKeYg1eLBgSXrXipLTudvpC8F6OudKeSA")

dni = sys.argv[1]
gender = sys.argv[2]
chat_id = sys.argv[3]

def consulta_renaper(dni, gender, chat_id):
    try:
        url = "https://cnmza.org.ar/escribano/renaper/v2/api_renaper.php"
        cookies = {"PHPSESSID": "p7k0a9dfglq4tdp96aqj6hkub6"}
        data = {
            "dni": dni,
            "gender": gender,
            "codigoNotario": "704",
            "consultaRenaper": "1"
        }

        response = requests.post(url, cookies=cookies, data=data)

        if response.status_code == 200:
            response_data = response.json()
            estado = response_data.get('estado')
            datoRenaper = response_data.get('datoRenaper', {})

            formatted_data = (
                f"`𝗚𝗢𝗕𝗕𝗢𝗧.𝗡𝗘𝗧 🏴‍☠️\n\n"
                f"➜ Nombre: {datoRenaper.get('nombres')}\n"
                f"➜ Apellido: {datoRenaper.get('apellido')}\n"
                f"➜ Nacimiento: {datoRenaper.get('fecha_nacimiento')}\n"
                f"➜ IdCiudadano: {datoRenaper.get('id_ciudadano')}\n"
                f"➜ CUIL: {datoRenaper.get('cuil')}\n\n"
                f"[›››] Dirección\n\n"
                f"➜ Calle: {datoRenaper.get('calle')}\n"
                f"➜ Número: {datoRenaper.get('numero')}\n"
                f"➜ Piso: {datoRenaper.get('piso')}\n"
                f"➜ Departamento: {datoRenaper.get('departamento')}\n"
                f"➜ C.Postal: {datoRenaper.get('codigo_postal')}\n"
                f"➜ Barrio: {datoRenaper.get('barrio')}\n"
                f"➜ Monoblock: {datoRenaper.get('monoblock')}\n"
                f"➜ Ciudad: {datoRenaper.get('ciudad')}\n"
                f"➜ Municipio: {datoRenaper.get('municipio')}\n"
                f"➜ Provincia: {datoRenaper.get('provincia')}\n"
                f"➜ País: {datoRenaper.get('pais')}\n\n"
                f"[›››] Información Extra\n\n"
                f"➜ Estado Fallecido: {datoRenaper.get('codigo_fallecido')}\n"
                f"➜ Mensaje Fallecido: {datoRenaper.get('mensaje_fallecido')}\n"
                f"➜ Origen Fallecido: {datoRenaper.get('origen_fallecido')}\n"
                f"➜ Fecha Fallecido: {datoRenaper.get('fecha_fallecido')}\n"
                f"➜ Id Consulta: {datoRenaper.get('idConsulta')}\n"
                f"➜ Ejemplar: {datoRenaper.get('ejemplar')}\n"
                f"➜ Fecha Vencimiento: {datoRenaper.get('fecha_vencimiento')}\n"
                f"➜ Fecha Emisión: {datoRenaper.get('fecha_emision')}\n"
                f"➜ Id Trámite Principal: {datoRenaper.get('id_tramite_principal')}\n"
                f"➜ Id Trámite Tarjeta Reimpresa: {datoRenaper.get('id_tramite_tarjeta_reimpresa')}\n\n"
                "`"
            )

            foto_base64 = datoRenaper.get('foto')
            if foto_base64:
                foto_bytes = base64.b64decode(foto_base64)
                image = Image.open(BytesIO(foto_bytes))
                image_dir = os.path.abspath('./fotos')
                os.makedirs(image_dir, exist_ok=True)
                image_path = os.path.join(image_dir, f"{dni}.png")
                image.save(image_path)
                with open(image_path, "rb") as photo:
                    bot.send_photo(chat_id, photo)
                print(image_path)  # Imprime la ruta absoluta de la imagen generada

            print(f"\n\033[92mConsulta realizada para el DNI {dni} {gender}\033[0m\n")

    except Exception as e:
        bot.send_message(chat_id, f"Ocurrió un error durante la consulta")

consulta_renaper(dni, gender, chat_id)
