import asyncio
import requests
from capmonstercloudclient import CapMonsterClient, ClientOptions
from capmonstercloudclient.requests import RecaptchaV2ProxylessRequest
from bs4 import BeautifulSoup
import json
import openpyxl
import sys

client_options = ClientOptions(api_key="f8359ff3743bf3fa23deb398a12e000d")
cap_monster_client = CapMonsterClient(options=client_options)

async def solve_captcha(website_url, website_key):
    return (await cap_monster_client.solve_captcha(RecaptchaV2ProxylessRequest(websiteUrl=website_url,
                                                websiteKey=website_key)))["gRecaptchaResponse"]

def obtener_cuit(dni):

    info_terceros = 'https://mi.nosis.com/InformeTerceros/RealizarBusqueda'
    dnis = {'query': dni}
    
    with requests.session() as s:
        r = s.post(info_terceros, data=dnis)
        content = r.content
        datos = json.loads(content)
        html_tabla = datos['HtmlTabla']
        soup = BeautifulSoup(html_tabla, 'html.parser')
        documento = soup.find("div", {"class": "resultados-doc align-self-center col-12 col-sm-3 col-lg-2"}).get_text(strip=True)
    
    return documento.replace("-", "")

def guardar_datos_en_excel(datos, nombre_archivo='../../leads.xlsx'):

    try:
        libro = openpyxl.load_workbook(nombre_archivo)
        hoja = libro.active
    except FileNotFoundError:
        libro = openpyxl.Workbook()
        hoja = libro.active
        hoja.append(["DNI", "CUIT", "Nombres", "Apellidos", "Email1", "Email2", "Email3", "Email4", "Email5", 
                     "Telefono1", "Telefono2", "Telefono3", "Telefono4", "Telefono5", "Direccion1", "Banco1", "Banco2", "Banco3", "Banco4", "Banco5"]) 

    identidad = datos['data']['informe']['identidad']
    dni = identidad.get('numero_documento', 'N/A')
    cuit = identidad.get('cuit', 'N/A')
    nombre_completo = identidad.get('nombre_completo', 'N/A')
    nombres = " ".join(nombre_completo.split()[:-1])
    apellidos = nombre_completo.split()[-1]
    
    emails = [''] * 5
    if isinstance(datos['data']['informe'].get('mails', []), list):
        for i, email in enumerate(datos['data']['informe']['mails']):
            if i < 5:
                emails[i] = email.get('mail', '')
    
    telefonos = [''] * 5
    if isinstance(datos['data']['informe'].get('telefonosDeclarados', []), list):
        for i, tel in enumerate(datos['data']['informe']['telefonosDeclarados']):
            if i < 5:
                telefonos[i] = tel.get('numero', '')
    
    direcciones = [''] * 1
    if isinstance(datos['data']['informe'].get('domicilios', []), list):
        for i, dir in enumerate(datos['data']['informe']['domicilios']):
            if i < 1:
                direcciones[i] = f"{dir.get('calle', '')} {dir.get('altura', '')}, {dir.get('localidad', '')}, {dir.get('provincia', '')}, {dir.get('cp', '')}"
    
    bancos = [''] * 5
    bcra_data = datos['data']['informe'].get('bcra', {})
    if isinstance(bcra_data, dict) and isinstance(bcra_data.get('datos', []), list):
        for i, deuda in enumerate(bcra_data['datos']):
            if i < 5:
                bancos[i] = deuda.get('nombre', '')
    
    if any(emails):
        if any(bancos):
            hoja.append([dni, cuit, nombres, apellidos] + emails + telefonos + direcciones + bancos)
            libro.save(nombre_archivo)

def main(dni):
    cuit = obtener_cuit(dni)
    print(f"CUIT obtenido: {cuit}")

    s = requests.Session()
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.5060.66 Safari/537.36',
    }

    website_url = 'https://servicio.infoexperto.com.ar/info/Login'
    website_key = '6LeTwiwUAAAAALhF_oSKime4LfSHb4bZ0JqsC7qp' 

    captcha_response_login = asyncio.run(solve_captcha(website_url, website_key))
    
    data = {
        'mail': 'valeria.cadaillon@autohaus.com.ar',
        'password': 'Tito2011',
        'tokenCaptcha': captcha_response_login,
        'elegiElFuturo': 'orolurquxnwxobrtbrr'
    }

    login = s.post('https://servicio.infoexperto.com.ar/api/user/login', headers=headers, data=data)

    try:
        login2 = login.json()
    except ValueError:
        print("Error al decodificar la respuesta JSON")
        print("Respuesta de la solicitud de inicio de sesión:", login.text)
        return

    print("Respuesta de inicio de sesión:", login2)
    
    if 'metadata' not in login2 or 'token' not in login2['metadata']:
        print("Error: La respuesta JSON no contiene los datos esperados.")
        return
    
    token = login2['metadata']['token']
    headers['Authorization'] = f'Bearer {token}'
    

    s.post(f'https://servicio.infoexperto.com.ar/app/informe/create-sesion/web2/{token}', headers=headers)
    s.post('https://servicio.infoexperto.com.ar/app/informe/usuarios', headers=headers)
    s.post('https://servicio.infoexperto.com.ar/app/informe/usuario/recargar', headers=headers)

    busqueda_data = {
        'identidad': cuit,
        'edad': '18,100',
        'filtros': '{"provincia":"","sexo":"","tipo_entidad":"","domicilio":"","localidad":"","cp":""}',
        'elegiElFuturo': 'orolurquxnwxobjqbln'
    }
    busqueda_response = s.post('https://servicio.infoexperto.com.ar/api/informe/busquedaAvanzada', headers=headers, data=busqueda_data)
    print("Respuesta de búsqueda avanzada:", busqueda_response.json())

    verificar_historial_data = {
        'cuit': cuit,
        'token': token  
    }
    historial_response = s.post('https://servicio.infoexperto.com.ar/api/informe/verificarInformeHistorial', headers=headers, data=verificar_historial_data)
    print("Respuesta de verificación de historial:", historial_response.json())
 
    pedir_informe_data = {
        'cuit': cuit,
        'token': token,  
        'elegiElFuturo': 'orolurquxnwxobjnblo'
    }
    pedir_informe_response = s.post('https://servicio.infoexperto.com.ar/api/informe/pedirInforme', headers=headers, data=pedir_informe_data)
    print("Respuesta de pedir informe:", pedir_informe_response.json())
    
    informe_id = pedir_informe_response.json().get('data', {}).get('id')
    if informe_id:
        captcha_response_descarga = asyncio.run(solve_captcha(website_url, website_key))
        
        descargar_informe_data = {
            'idInforme': informe_id,
            'seccionesInforme': '["Identidad","Localizacion","Actividad","Finanzas","Bienes","Legal","Estadisticas"]',
            'tokenCaptcha': captcha_response_descarga,
            'elegiElFuturo': 'orolurquxnwxobjcbtt',
            'token': token  
        }
        pdf_response = s.post('https://servicio.infoexperto.com.ar/api/informe/descargarInforme', headers=headers, data=descargar_informe_data)

        pdf_filename = f'./log/ie/{dni}.pdf'
        with open(pdf_filename, 'wb') as pdf_file:
            pdf_file.write(pdf_response.content)
        
        print(f'PDF guardado como {pdf_filename}')
        guardar_datos_en_excel(pedir_informe_response.json(), '../../leads.xlsx')
        
    else:
        print("No se pudo obtener el ID del informe.")

if __name__ == '__main__':
    dni = sys.argv[1]
    asyncio.run(main(dni))

