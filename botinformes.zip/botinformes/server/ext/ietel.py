import asyncio
import requests
from capmonstercloudclient import CapMonsterClient, ClientOptions
from capmonstercloudclient.requests import RecaptchaV2ProxylessRequest
import json
from requests_toolbelt.multipart.encoder import MultipartEncoder

client_options = ClientOptions(api_key="7f6346b2cda450f5a39ecf8d32bca2db")
cap_monster_client = CapMonsterClient(options=client_options)

async def solve_captcha(website_url, website_key):
    return (await cap_monster_client.solve_captcha(RecaptchaV2ProxylessRequest(websiteUrl=website_url, websiteKey=website_key)))["gRecaptchaResponse"]

def obtener_pdf():
    s = requests.Session()
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.5060.66 Safari/537.36',
    }

    website_url = 'https://servicio.infoexperto.com.ar/info/Login'
    website_key = '6LeTwiwUAAAAALhF_oSKime4LfSHb4bZ0JqsC7qp' 

    captcha_response_login = asyncio.run(solve_captcha(website_url, website_key))
    
    data = {
        'mail': 'valeria.cadaillon@autohaus.com.ar',
        'password': 'Tito2011',
        'tokenCaptcha': captcha_response_login,
        'elegiElFuturo': 'orolurquxnwxobrtbrr'
    }

    login = s.post('https://servicio.infoexperto.com.ar/api/user/login', headers=headers, data=data)
    
    try:
        login2 = login.json()
    except ValueError:
        print("Error al decodificar la respuesta JSON")
        print("Respuesta de la solicitud de inicio de sesión:", login.text)
        return

    print("Respuesta de inicio de sesión:", login2)
    
    if 'metadata' not in login2 or 'token' not in login2['metadata']:
        print("Error: La respuesta JSON no contiene los datos esperados.")
        return
    
    token = login2['metadata']['token']
    headers['Authorization'] = f'Bearer {token}'
    
    # Crear sesión
    s.post(f'https://servicio.infoexperto.com.ar/app/informe/create-sesion/web2/{token}', headers=headers)
    s.post('https://servicio.infoexperto.com.ar/app/informe/usuarios', headers=headers)
    s.post('https://servicio.infoexperto.com.ar/app/informe/usuario/recargar', headers=headers)
    
    
    telefono = "1122508929"  
    m = MultipartEncoder(
        fields={
            'telefono': telefono,
            'elegiElFuturo': 'orolurquonwxxbrrboj'
        }
    )
    headers['Content-Type'] = m.content_type
    busqueda_response = s.post('https://servicio.infoexperto.com.ar/api/informe/busquedaAvanzadaTelefono', headers=headers, data=m)
    
    if busqueda_response.status_code == 200:
        response_json = busqueda_response.json()
        if response_json.get('status') == 'success' and response_json.get('data'):
            print("Respuesta de búsqueda avanzada:", response_json)
        else:
            print("Sin datos")
    else:
        print("Error en la solicitud de búsqueda avanzada:", busqueda_response.status_code)

obtener_pdf()
