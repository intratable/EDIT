import { dirname } from 'path';
import { fileURLToPath } from 'url';
import { spawn } from 'child_process';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

export const pdfidarg = async (req, res) => {
    const { dni, gender, chatId } = req.body;

    if (!dni || !gender || !chatId) {
        res.status(400).send('Faltan datos necesarios');
        return;
    }

    console.log(`Received request with dni: ${dni}, gender: ${gender}, chatId: ${chatId}`);

    const pythonProcess = spawn('python', ['./server/ext/idarg.py', dni, gender, chatId]);

    pythonProcess.stdout.on('data', (data) => {
        console.log(`Python script output: ${data}`);
    });

    pythonProcess.stderr.on('data', (data) => {
        console.error(`Error en el script Python: ${data}`);
    });

    pythonProcess.on('close', (code) => {
        if (code !== 0) {
            res.status(500).send(`Error en el proceso Python con código ${code}`);
        } else {
            res.send('Consulta realizada.');
        }
    });
};
