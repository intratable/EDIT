import express from 'express';
import fetch from 'node-fetch';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';
import { spawn } from 'child_process';
import { TELEGRAM_BOT_TOKEN } from '../assets/config/config.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

export const buscarrs = async (req, res) => {
    try {
        const { info } = req.body;
        const chatidmain = req.body.chatId;
        const userMainDirscr = join(__dirname, './ext', 'rssearch.py');
        const comm = 'python';

        const args = [
            userMainDirscr,
            ...info
        ];

        const pythonProcess = spawn(comm, args);
        let responseData = '';

        pythonProcess.stdout.on('data', (data) => {
            console.log(`Python script output: ${data}`);
            responseData += data.toString();
        });

        pythonProcess.stderr.on('data', (data) => {
            console.error(`Error en el script Python: ${data}`);
        });

        pythonProcess.on('close', async (code) => {
            console.log(`Proceso de Python cerrado con código ${code}`);

            const lines = responseData.trim().split('\n');
            const chunkSize = 25;
            const chunks = [];

            for (let i = 0; i < lines.length; i += chunkSize) {
                chunks.push(lines.slice(i, i + chunkSize).join('\n'));
            }

            const botToken = TELEGRAM_BOT_TOKEN;
            const chatId = chatidmain;
            const telegramUrl = `https://api.telegram.org/bot${botToken}/sendMessage`;

            for (const chunk of chunks) {
                const telegramParams = {
                    chat_id: chatId,
                    text: '𝗚𝗢𝗕𝗕𝗢𝗧.𝗡𝗘𝗧 🏴‍☠️ \n➖➖➖➖➖➖\n' + chunk
                };
                try {
                    const response = await fetch(telegramUrl, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify(telegramParams),
                    });

                    const responseBody = await response.json();
                    if (!response.ok) {
                        throw new Error(`Error al enviar mensaje al bot de Telegram: ${responseBody.description}`);
                    }

                    console.log('Mensaje enviado al bot de Telegram.');
                } catch (err) {
                    console.error('Error al enviar mensaje al bot de Telegram:', err);
                    res.status(500).send('Error occurred while sending message to Telegram.');
                    return;
                }
            }

            res.send('Proceso completado.');
        });
    } catch (error) {
        console.error(error);
        res.status(500).send('Error occurred while processing /search');
    }
};
