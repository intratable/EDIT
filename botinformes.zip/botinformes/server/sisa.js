import FormData from 'form-data';
import axios from 'axios';
import fs from 'fs';
import pathlib from 'path';

const sisaVars = {};

async function loadSisaVars() {
  const xGwtHashRegEx = /\$strongName = '(\w{32})';/
  const dispHashRegEx = /,'dispatch','(\w{32})',/
  const secuHashRegEx = /,'service\/securityService','(\w{32})',/
  const listHashRegEx = /,'service\/list','(\w{32})',/
  const cmdbHashRegEx = /,'service\/cmdbService','(\w{32})',/

  const deskVarRegEx = /,([A-z0-9$_]{1,3})='desktop'/;
  const sfriVarRegEx = /,([A-z0-9$_]{1,3})='safari'/;

  const mainResp = await axios.get('https://sisa.msal.gov.ar/sisa/sisa/sisa.nocache.js');
  const mainBody = mainResp.data;

  let cachefileHash;
  try {
    const deskVarname = mainBody.match(deskVarRegEx)[1];
    const sfriVarname = mainBody.match(sfriVarRegEx)[1];

    const loadCmdRegEx = new RegExp(`;\\w\\(\\[${deskVarname},${sfriVarname}\\],(\\w{1,3})\\);`)
    const hashVarname = mainBody.match(loadCmdRegEx)[1];

    const hashStrRegEx = new RegExp(`,${hashVarname}='(\\w{32})',`);
    cachefileHash = mainBody.match(hashStrRegEx)[1];
  } catch (e) {
    return 'error';
  }

  const cachedSisa = getCached(cachefileHash);
  let sisaBody;
  if (!cachedSisa) {
    const sisaLink = `https://sisa.msal.gov.ar/sisa/sisa/${cachefileHash}.cache.js`;
    const sisaResp = await axios.get(sisaLink);
    sisaBody = sisaResp.data;
  } else {
    sisaBody = cachedSisa;
  }

  let xGwtHash, dispHash, secuHash, listHash, cmdbHash;
  try {
    xGwtHash = sisaBody.match(xGwtHashRegEx)[1];
    dispHash = sisaBody.match(dispHashRegEx)[1];
    secuHash = sisaBody.match(secuHashRegEx)[1];
    listHash = sisaBody.match(listHashRegEx)[1];
    cmdbHash = sisaBody.match(cmdbHashRegEx)[1];
  } catch (e) {
    return 'error';
  }

  Object.assign(sisaVars, {
    xGwtHash,
    dispHash,
    secuHash,
    listHash,
    cmdbHash
  });
}

class cookiedRequester {
  constructor() {
    this.cookies = {};
  }

  async get(url, config) {
    return this._request(url, {
      method: 'GET',
      ...config
    });
  }

  async post(url, config) {
    return this._request(url, {
      method: 'POST',
      ...config
    });
  }

  async _request(url, config) {
    config.headers = {
      ...(config.headers || {}),
      Cookie: this.stringifyCookies()
    };

    const resp = await axios({
      url,
      ...config
    });
    let setcookie;
    if ((setcookie = resp.headers['set-cookie'])?.length) {
      this.applyCookies(setcookie);
    }

    return resp;
  }

  applyCookies(setcookie) {
    for (let cookie of setcookie) {
      const kv = cookie.split('; ')[0];
      const [key, value] = kv.split('=');

      this.cookies[key] = value;
    }
  }

  clearCookies() {
    this.cookies = {};
  }

  checkCookie(cookieName) {
    return Object.keys(this.cookies).includes(cookieName);
  }

  stringifyCookies() {
    const keys = Object.keys(this.cookies);
    return keys.map(key => key + '=' + this.cookies[key]).join('; ')
  }
}

let commonHeaders;

function generateHeaders() {
  commonHeaders = {
    "accept": "*/*",
    "accept-language": "ru,en;q=0.9,be;q=0.8,cy;q=0.7,es;q=0.6",
    "cache-control": "no-cache",
    "content-type": "text/x-gwt-rpc; charset=UTF-8",
    "pragma": "no-cache",
    "sec-ch-ua": "\"Chromium\";v=\"104\", \" Not A;Brand\";v=\"99\", \"Yandex\";v=\"22\"",
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": "\"Windows\"",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-origin",
    "x-gwt-module-base": "https://sisa.msal.gov.ar/sisa/sisa/",
    "x-gwt-permutation": sisaVars.xGwtHash,
    "User-Agent": 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.5112.114 YaBrowser/22.9.1.1095 Yowser/2.5 Safari/537.36',
    "Referer": "https://sisa.msal.gov.ar/sisa/",
    "Referrer-Policy": "strict-origin-when-cross-origin"
  };
}

const cr = new cookiedRequester();

async function renewSession() {
  cr.clearCookies();
  try {
    await cr.post("https://sisa.msal.gov.ar/sisa/sisa/dispatch", {
      headers: {
        ...commonHeaders
      },
      data: `7|0|6|https://sisa.msal.gov.ar/sisa/sisa/|${sisaVars.dispHash}|net.customware.gwt.dispatch.client.standard.StandardDispatchService|execute|net.customware.gwt.dispatch.shared.Action|ar.gob.msal.sisa.shared.rpc.action.LoadEnvironmentAction/1047162293|1|2|3|4|1|5|6|`
    });
  } catch (e) {
    console.error(e);
  }
}

async function checkSession() {
  if (!cr.checkCookie('JSESSIONID')) {
    await renewSession();
    await logIn();
  }
}

async function logIn() {
  if (!cr.checkCookie('JSESSIONID')) await renewSession();

  const user = 'ctheaux';
  const pass = 'Sisa2356!';
  const resp = await cr.post("https://sisa.msal.gov.ar/sisa/sisa/service/securityService", {
    headers: commonHeaders,
    data: `7|0|7|https://sisa.msal.gov.ar/sisa/sisa/|${sisaVars.secuHash}|ar.gob.msal.sisa.client.usuario.service.SecurityService|login|java.lang.String/2004016611|${user}|${pass}|1|2|3|4|2|5|5|6|7|`,
  });

  const data = resp.data;
  if (!data) return 'error';
  if (!data.startsWith('//OK')) {
    processErrors(data);
  }
}

async function getInternalDNIId(dni, sexo) {
  await checkSession();
  const resp = await cr.post("https://sisa.msal.gov.ar/sisa/sisa/service/list", {
    headers: {
      ...commonHeaders
    },
    data: `7|0|17|https://sisa.msal.gov.ar/sisa/sisa/|${sisaVars.listHash}|ar.gob.msal.sisa.client.commons.components.lista.service.ListService|getPage|java.lang.Integer/3438268394|java.util.List|Z|ar.gob.msal.sisa.shared.model.list.ComplexFilter/30068811|java.util.ArrayList/4159755760|ar.gob.msal.sisa.client.commons.components.lista.simple.SearchFilter/1978531670|80200|ar.gob.msal.sisa.client.entitys.list.Filter$OPERATION/3408968308|${dni}|80216|${sexo}|80209|1|1|2|3|4|10|5|5|5|6|6|5|7|5|6|8|5|382|5|1|-2|9|3|10|11|12|0|0|0|13|0|10|14|-5|0|0|15|0|10|16|-5|0|0|17|0|9|0|0|1|5|25|0|0|`,
  });

  const data = resp.data;
  if (!data) return 'error';
  if (!data.startsWith('//OK')) {
    processErrors(data);
  }

  const parsed = simpleParseAnswer(data);
  const id = extractInternalIdFromAnswer(parsed.data);

  return id;
}

function extractInternalIdFromAnswer(data) {
  const mainArr = data?.[data.length - 3];
  for (let entry of mainArr) {
    if (typeof entry === 'string' && entry.startsWith('70'))
      return entry;
  }

  return 'error';
}

function simpleParseAnswer(data) {
  if (!data.startsWith('//')) return 'error';
  try {
    const OP = data.slice(0, 4);
    const load = data.slice(4);

    const jsonPayload = JSON.parse(load);

    return {
      op: OP,
      data: jsonPayload
    };
  } catch (error) {
    return 'error';
  }
}

function processErrors(data) {
  if (data.startsWith('//EX')) {
    cr.clearCookies();
    console.warn('Session expired and deleted');
  } else {
    return 'error';
  }
}

async function getPersonInfoCmdb(internalId) {
  await checkSession();
  const resp = await cr.post("https://sisa.msal.gov.ar/sisa/sisa/service/cmdbService", {
    headers: commonHeaders,
    data: `7|0|7|https://sisa.msal.gov.ar/sisa/sisa/|${sisaVars.cmdbHash}|ar.gob.msal.sisa.client.cmdb.service.CmdbService|load|java.lang.String/2004016611|java.lang.Boolean/476441737|${internalId}|1|2|3|4|2|5|6|7|6|0|`,
    method: "POST"
  });

  const { op, data } = simpleParseAnswer(resp.data);

  if (op !== '//OK') {
    processErrors(resp.data);
    return 'error';
  }

  return data;
}

async function fetchAddressData(internalId) {
  await checkSession();
  const resp = await cr.post("https://sisa.msal.gov.ar/sisa/sisa/service/list", {
    headers: commonHeaders,
    data: `7|0|17|https://sisa.msal.gov.ar/sisa/sisa/|${sisaVars.listHash}|ar.gob.msal.sisa.client.commons.components.lista.service.ListService|getPage|java.lang.Integer/3438268394|java.util.List|Z|ar.gob.msal.sisa.shared.model.list.ComplexFilter/30068811|java.util.ArrayList/4159755760|ar.gob.msal.sisa.client.commons.components.lista.simple.SearchFilter/1978531670|80100|ar.gob.msal.sisa.client.entitys.list.Filter$OPERATION/3408968308|${internalId}|80101|ar.gob.msal.sisa.client.entitys.list.Filter$OPERATOR/860546718|(4)|(5)|1|2|3|4|10|5|5|5|6|6|5|7|5|6|8|5|381|5|1|-2|9|3|10|11|12|0|0|0|13|0|10|14|-5|15|6|0|16|0|10|14|-5|-7|0|17|0|0|0|1|5|25|0|0|`,
  });

  const { op, data } = simpleParseAnswer(resp.data);

  if (op !== '//OK') {
    processErrors(resp.data);
    return 'error';
  }

  const actualdata = data[data.length - 3];
  const ad = actualdata;

  let dom = ad[9];
  let calle = '--', numero = '--';
  if (dom && dom.length) {
    dom = dom.trim().split(' ');
    calle = dom.slice(0, -1).join(' ');
    numero = dom[dom.length - 1];
  }

  return {
    calle: calle,
    numero: numero,
    cpostal: ad[13],
    provincia: ad[10],
  };
}

async function fetchPersonInfo(dni, sexo) {
    const intId = await getInternalDNIId(dni, sexo);
    const info = await getPersonInfoCmdb(intId);
    const dataArr = info[info.length - 3];
    const da = dataArr;
  
    const addressData = await fetchAddressData(intId);
    let tramite = "";
    let nombre = "", apellido = "", fechaNacimiento = "", nacionalidad = "", estadoCivil = "", cuil = "", ocupacion = "";
  
    for (let i = 0; i < 1000; i++) {
      if (da[i].length === 9 && tramite === "") {
        tramite = da[i];
      }
      if (da[i].length > 0) {
        switch (i) {
          case 2: // Indices aproximados basados en la estructura de los datos
            nombre = da[i];
            break;
          case 3:
            apellido = da[i];
            break;
          case 4:
            fechaNacimiento = da[i];
            break;
          case 5:
            nacionalidad = da[i];
            break;
          case 6:
            estadoCivil = da[i];
            break;
          case 7:
            cuil = da[i];
            break;
          case 8:
            ocupacion = da[i];
            break;
          default:
            break;
        }
      }
    }
  
    return {
      nombre,
      apellido,
      fechaNacimiento,
      nacionalidad,
      estadoCivil,
      cuil,
      ocupacion,
      tramite,
      addressData
    };
  }
  

function getCached(hash) {
  const path = pathlib.join(__dirname, '../cache/', hash + '.cache.js');
  if (fs.existsSync(path)) {
    const file = fs.readFileSync(path);
    return file.toString();
  }
  return null;
}


const dni = '12345678'; // Define el DNI aquí
const sexo = 'M'; // Define el sexo aquí

async function main() {
    await loadSisaVars();
    generateHeaders();
    await checkSession();
    const sisa = await fetchPersonInfo(dni, sexo);
    console.log(sisa);
  }
  
  main();
